import { useState } from "react";
import axios from "axios";

export default function Admin() {
  const [title, setTitle] = useState("");
  const [price, setPrice] = useState("");
  const [file, setFile] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("title", title);
    formData.append("price", price);
    formData.append("file", file);

    try {
      await axios.post(import.meta.env.VITE_API_URL + "/api/articles", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      alert("Article uploaded successfully!");
      setTitle(""); setPrice(""); setFile(null);
    } catch (err) {
      console.error(err);
      alert("Error uploading article.");
    }
  };

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Upload New Article</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input type="text" placeholder="Title" className="border p-2 w-full" value={title} onChange={(e) => setTitle(e.target.value)} />
        <input type="number" placeholder="Price" className="border p-2 w-full" value={price} onChange={(e) => setPrice(e.target.value)} />
        <input type="file" accept="application/pdf" onChange={(e) => setFile(e.target.files[0])} />
        <button className="bg-blue-600 text-white px-4 py-2 rounded">Upload</button>
      </form>
    </div>
  );
}
