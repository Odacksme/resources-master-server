import { Link } from "react-router-dom";

export default function ArticleCard({ article }) {
  return (
    <div className="bg-white p-4 shadow rounded">
      <h2 className="text-lg font-bold">{article.title}</h2>
      <p className="text-gray-600">Price: ${article.price}</p>
      <Link
        to={`/article/${article._id}`}
        className="mt-2 inline-block bg-blue-500 text-white px-3 py-1 rounded"
      >
        View
      </Link>
    </div>
  );
}
