# Resources Master – Frontend
React + Vite + Tailwind. Create a `.env` file with:
```
VITE_API_URL=http://localhost:5000
```
Run:
```
npm install
npm run dev
```
Build:
```
npm run build
```
