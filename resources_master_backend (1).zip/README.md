# Resources Master – Backend
Node.js + Express + MongoDB + Multer (PDF uploads)

1. Create `.env` from `.env.example` and fill values.
2. Install & run:
```
npm install
npm start
```
API:
- GET /api/articles
- GET /api/articles/:id
- POST /api/articles  (multipart/form-data: title, price, file[PDF])
Uploads are saved in `/uploads` folder.
