import express from "express";
import multer from "multer";
import path from "path";

import { getArticles, getArticle, uploadArticle } from "../controllers/articleController.js";

const router = express.Router();

const storage = multer.diskStorage({
  destination: "uploads/",
  filename: (req, file, cb) => cb(null, Date.now() + "-" + file.originalname.replace(/\s+/g, '_'))
});
const fileFilter = (req, file, cb) => {
  if (file.mimetype === "application/pdf") cb(null, true);
  else cb(new Error("Only PDF allowed"));
};
const upload = multer({ storage, fileFilter });

router.get("/", getArticles);
router.get("/:id", getArticle);
router.post("/", upload.single("file"), uploadArticle);

export default router;
