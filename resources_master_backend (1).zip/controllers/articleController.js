import Article from "../models/Article.js";

export const getArticles = async (req, res) => {
  const articles = await Article.find().sort({ createdAt: -1 });
  res.json(articles);
};

export const getArticle = async (req, res) => {
  const article = await Article.findById(req.params.id);
  if (!article) return res.status(404).json({ error: "Not found" });
  res.json(article);
};

export const uploadArticle = async (req, res) => {
  try {
    const { title, price } = req.body;
    if (!req.file) return res.status(400).json({ error: "PDF file required" });
    const fileUrl = `/uploads/${req.file.filename}`;
    const previewUrl = fileUrl; // TODO: replace with watermarked preview
    const article = await Article.create({ title, price, fileUrl, previewUrl });
    res.json(article);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Upload failed" });
  }
};
