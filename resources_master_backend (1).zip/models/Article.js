import mongoose from "mongoose";

const articleSchema = new mongoose.Schema({
  title: { type: String, required: true },
  price: { type: Number, required: true },
  fileUrl: { type: String, required: true },
  previewUrl: { type: String, required: true }
}, { timestamps: true });

export default mongoose.model("Article", articleSchema);
